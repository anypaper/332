#!/bin/bash
export server_ip=10.0.0.10
export client_ip=10.0.0.11
export test_duration=100


for i in {1..100}
do
   iperf -t $test_duration -c $server_ip -B $client_ip &> /home/vmserver09/new-sfc-test/iperf/client_iperf_out_$i
   echo $i | ssh root@10.0.0.1 "cat >> /root/ms2453/iperf-status/status.txt"
done


