#!/bin/bash
export server_ip=10.0.0.10; 
export APACHE_REQ_COUNT=50000; 
export APACHE_REQ_CONCURRENCY=50
for i in {1..100}
do
  echo 'in iteration'
  echo $i
  sudo ab -B 10.0.0.11 -n $APACHE_REQ_COUNT -c $APACHE_REQ_CONCURRENCY -e /root/ms2453/new-sfc/apache/out_$i http://$server_ip/index.html > /root/ms2453/new-sfc/apache/stdout_$i
  echo $i | ssh root@128.232.82.111 "cat >> /root/ms2453/apache-status/status.txt"
done
