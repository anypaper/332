#!/bin/bash
export server_ip=10.0.0.10
export client_ip=10.0.0.11
export server_ssh_ip=40.121.4.205

for i in {1..100}
do
  echo 'in iteration'
  echo $i
  echo 'going to launch server'
  ssh -o StrictHostKeyChecking=no $server_ssh_ip 'iperf -s -D -B "'$server_ip'" &> /home/murali/iperf_out/server_iperf_out_"'$i'"'
  sleep 10 
  echo 'going to launch client'
  iperf -t 170 -c $server_ip -B $client_ip &> /home/murali/iperf_out/client_iperf_out_$i
  ssh -o StrictHostKeyChecking=no $server_ssh_ip 'sudo killall iperf 2>&1'
  sleep 60
done
